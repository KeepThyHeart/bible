This is a Keep Thy Heart backup.

It is a standard ZIP archive. The first entry, manifest.json, lists every other
entry with its size and SHA-256 and describes the sections it holds.

  user/<table>.ndjson   one JSON object per row
  notes/                note files, exactly as stored on disk
  extensions/           data that extensions asked to have backed up
  settings/             preferences

If you are reading this in an unencrypted export, anyone with this file can read
everything in it. Keep it somewhere safe.
